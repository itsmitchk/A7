/**
 * Started by Najib 3/21/18
 **/

///////////////////////////////////////////////////////////////////
// INCLUDES GO HERE
///////////////////////////////////////////////////////////////////
#include "functions.h"
#include "bigint/bigint.h"


int main(int argc, char *argv[]) {
  (void) argc;
  frequencies(argv[1]);
    return 0;
}
