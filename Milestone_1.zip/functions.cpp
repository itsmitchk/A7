/**
 * Started by Najib 3/21/18
 **/


///////////////////////////////////////////////////////////////////
// INCLUDES GO HERE
///////////////////////////////////////////////////////////////////
#include <iostream>
#include "functions.h"
#include "bigint/bigint.h"

std::vector<int> getVec(std::string filename){
  int first, second, third,index;
  std::vector<int> vec(17575,0);
  std::string bigStr;
  char c;
  std:: ifstream infile;
  infile.open(filename);
  // incase the filename isnt vaild
  if(infile.fail()){
    std::cerr << "functions: "<< filename <<": no such file or directory" << '\n';
 }
 char c1,c2,c3,lower;
 int count =0;
while (infile.get(c) and count <2) {
  if(isalpha(c)){
    lower = tolower(c);
    bigStr += lower;
    count +=1;
  }
  else{
      continue;
    }
  }
  c1 = bigStr[0];
  c2 =bigStr[1];
    while (infile.get(c)) {
      if(isalpha(c)){
        lower = tolower(c);
        c3 = lower;
      }
      else{
          continue;
        }
  first = c1 - 97;
  second = c2 - 97;
  third = c3 -97;
  index = (first * 26 * 26) + (second * 26) + third;
  vec[index] +=1;
  c1 = c2;
  c2 = c3;
}
  return vec;
}
void to_file(std::vector<int> vec){
  std::cout << vec[0];
  for(unsigned long i = 1;i< vec.size();i++){
    std::cout << " ";
    std::cout << vec[i];

  }
  std::cout <<'\n';
}
  /*
  outStr += '\n';
  std::string outfilename = "frequencies.txt";
  std::ofstream outfile(outfilename);
   if (!outfile.fail()){
     //redirect outstr into out filename
      outfile << outStr;
      outfile.close();
    } else {
      // if fails
      std:: cerr << "Could not open file " << outfilename << std::endl;
      exit(EXIT_FAILURE);
     }

}
*/
void frequencies(std::string filename){
  //print(getVec(getString(filename)));
  std::vector<int> tempVec = getVec(filename);
  to_file(tempVec);
}
///////////////////////////////////////////////////////////////////
// FUNCTION DEFINITIONS GO HERE
///////////////////////////////////////////////////////////////////
