/**
 * Started by Najib 3/21/18
 **/

#ifndef __FUNCTIONS_H__
#define __FUNCTIONS_H__

///////////////////////////////////////////////////////////////////
// INCLUDES GO HERE
///////////////////////////////////////////////////////////////////
#include "bigint/bigint.h"
#include <iostream>
#include <vector>
#include <string>
#include <fstream>

//class function {
//private:
//    std::vector<vec_bin> vec;

//public:


  std::vector<int> getVec(std::string filename);

  void to_file(std::vector<int> vec);

  void frequencies(std::string filename);

//};

///////////////////////////////////////////////////////////////////
// FUNCTION HEADERS GO HERE
///////////////////////////////////////////////////////////////////




#endif
